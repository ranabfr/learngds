import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plane, BookOpen, Users, Award, Phone, Mail, MapPin, Clock, CheckCircle, Star } from "lucide-react";
const Index = () => {
  const gdsSystemsData = [{
    name: "Basic Training",
    description: "Foundation level GDS training covering essential skills for beginners",
    features: ["System Introduction & Navigation", "Selling Flights & PNR Creation", "Fare Display & Pricing", "Ticketing & Review"]
  }, {
    name: "Advanced Training",
    description: "Professional level GDS training for experienced users and career advancement",
    features: ["Advanced PNR Management", "Reissue & Refund", "Queue Management & Admin Tools", "Miscellaneous & Troubleshooting"]
  }, {
    name: "All GDS Systems",
    description: "Complete training coverage for Travelport, Sabre, and Amadeus platforms",
    features: ["Travelport (Galileo)", "Sabre Red Workspace", "Amadeus Selling Platform", "Cross-platform Skills"]
  }];
  const courseFeatures = ["Hands-on practical training", "Industry-standard certification", "Flexible scheduling options", "Expert instructor guidance", "Real-world case studies", "Job placement assistance"];
  return <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <div className="flex items-center gap-2 mb-4">
                <Plane className="h-8 w-8 text-yellow-400" />
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  Professional GDS Training
                </Badge>
              </div>
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Master <span className="gradient-text">GDS Systems</span>
              </h1>
              <p className="text-xl mb-8 text-blue-100 leading-relaxed">
                Learn Travelport, Sabre, and Amadeus from industry expert Amjad Hossain Rana. 
                Get certified and advance your career in the travel industry.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="btn-primary text-lg px-8 py-3">
                  <BookOpen className="mr-2 h-5 w-5" />
                  Start Learning
                </Button>
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                  <Phone className="mr-2 h-5 w-5" />
                  Contact Trainer
                </Button>
              </div>
            </div>
            <div className="relative animate-float">
              <img src="https://static-us-img.skywork.ai/prod/user/head_picture/1987752445071368192_home header.webp?image_process=quality,q_90/resize,w_1280/format,webp" alt="GDS Systems Training" className="rounded-2xl shadow-2xl w-full max-w-md mx-auto" style={{objectFit: 'cover'}} />
            </div>
          </div>
        </div>
      </section>

      {/* Trainer Profile Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <img src="https://static-us-img.skywork.ai/prod/user/head_picture/1987749960508284928_f14c6a57-d5d1-4df0-8bcd-cdbeee6a3abe.png?image_process=quality,q_90/resize,w_1280/format,webp" alt="Professional Training" className="rounded-2xl shadow-xl w-full sk-edit-loading h-[512.5499877929688px] object-cover" />
            </div>
            <div>
              <Badge className="mb-4 bg-blue-100 text-blue-800">
                <Award className="mr-2 h-4 w-4" />
                Expert Trainer
              </Badge>
              <h2 className="text-4xl font-bold mb-6">Meet Your Instructor</h2>
              <h3 className="text-2xl font-semibold text-blue-600 mb-4">Amjad Hossain Rana</h3>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                With years of experience in the travel industry, Amjad brings practical knowledge 
                and real-world expertise to every training session. Specializing in all major GDS 
                systems, he has helped hundreds of students launch successful careers in travel technology.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-blue-600" />
                  <span className="font-medium">+880 1829-280872 (WhatsApp)</span>
                </div>
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-blue-600" />
                  <span className="font-medium">ranabfr@gmail.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="h-5 w-5 text-blue-600" />
                  <span className="font-medium">Kabbokash Super Market, 4th Floor, Suite - 14, 3D Kawran Bazar Road, Dhaka, Bangladesh</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* GDS Systems Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-blue-100 text-blue-800">
              <BookOpen className="mr-2 h-4 w-4" />
              Course Curriculum
            </Badge>
            <h2 className="text-4xl font-bold mb-6">Master All Major GDS Systems</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive training on the three leading Global Distribution Systems used by travel professionals worldwide.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {gdsSystemsData.map((system, index) => <Card key={index} className="card-hover border-0 shadow-lg">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Plane className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl">{system.name}</CardTitle>
                  <CardDescription className="text-base">{system.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {system.features.map((feature, idx) => <li key={idx} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>)}
                  </ul>
                </CardContent>
              </Card>)}
          </div>

          <div className="text-center">
            <img src="https://static-us-img.skywork.ai/prod/user/head_picture/1987744711483629568_Gemini_Generated_Image_s93a9ts93a9ts93a.png?image_process=quality,q_90/resize,w_1280/format,webp" alt="GDS Comparison" className="rounded-2xl shadow-xl mx-auto max-w-4xl w-full sk-edit-loading h-[597.3250122070312px] object-cover" />
          </div>
        </div>
      </section>

      {/* Course Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4 bg-green-100 text-green-800">
                <Star className="mr-2 h-4 w-4" />
                Premium Training
              </Badge>
              <h2 className="text-4xl font-bold mb-6">Why Choose Our GDS Training?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our comprehensive training program is designed to give you practical, job-ready skills 
                in all major GDS systems. Learn from an industry expert with proven results.
              </p>
              <div className="grid sm:grid-cols-2 gap-4">
                {courseFeatures.map((feature, index) => <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span className="font-medium">{feature}</span>
                  </div>)}
              </div>
            </div>
            <div>
              <img src="https://static-us-img.skywork.ai/prod/user/head_picture/1987738569709756416_2 lg.jpg?image_process=quality,q_90/resize,w_1280/format,webp" alt="Aviation Training" className="rounded-2xl shadow-xl w-full sk-edit-loading h-[911.2000122070312px] object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-6">Ready to Start Your GDS Journey?</h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Contact Amjad Hossain Rana today to discuss your training needs and career goals.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <Card className="bg-white/10 border-white/20 text-white">
              <CardHeader className="text-center">
                <Phone className="h-8 w-8 mx-auto mb-4 text-yellow-400" />
                <CardTitle>Call or WhatsApp</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="font-semibold">+880 1829-280872</p>
                <p className="text-sm text-blue-100 mt-2">Available for consultation</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20 text-white">
              <CardHeader className="text-center">
                <Mail className="h-8 w-8 mx-auto mb-4 text-yellow-400" />
                <CardTitle>Email</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="font-semibold">ranabfr@gmail.com</p>
                <p className="text-sm text-blue-100 mt-2">Quick response guaranteed</p>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20 text-white">
              <CardHeader className="text-center">
                <MapPin className="h-8 w-8 mx-auto mb-4 text-yellow-400" />
                <CardTitle>Location</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <p className="font-semibold text-sm">Kabbokash Super Market</p>
                <p className="text-sm text-blue-100 mt-2">4th Floor, Suite - 14, Dhaka</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="text-center mt-12">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 text-lg px-8 py-3">
              <Phone className="mr-2 h-5 w-5" />
              Contact Now
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Plane className="h-6 w-6 text-blue-400" />
              <h3 className="text-xl font-bold">GDS Learning Center</h3>
            </div>
            <p className="text-gray-400 mb-4">Professional GDS Training by Amjad Hossain Rana</p>
            <Separator className="my-6 bg-gray-700" />
            <p className="text-sm text-gray-500">
              © 2024 GDS Learning Center. All rights reserved. | Travelport • Sabre • Amadeus Training
            </p>
          </div>
        </div>
      </footer>
    </div>;
};
export default Index;